﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    //headers of the examples.
    public static class Common
    {
        public static string[] arrHeader =
        {
        "Write a function that computes a function.",
        "Write a function that receives an hour and a minute from an analog clock and calculates the inner angle between them.",
        "Write a function that converts a given integer into a Roman Numeral - the method needs to receive an integer and return a string (The integer can be between 1 and 3999).",
        "Write a function that, given two strings, test whether one is an anagram of the other.",
        "Write a function to perform basic string compression using the counts of repeated characters",
        "Swap two integers without using a temporary variable.",
        "Write a function such that if an element in an MxN matrix is 0, its entire row and column are set to 0 and then printed out"
        }; 
    }
}
