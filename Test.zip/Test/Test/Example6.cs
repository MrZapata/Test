﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Example6
    {
        public void fHeader(int value)
        {
            Console.WriteLine(Common.arrHeader[value]);
        }

        public void fAction(string[] args)
        {
            int var1 = Convert.ToInt32(args[0]);
            int var2 = Convert.ToInt32(args[1]);

            Console.WriteLine("Value in var1 is {0}, value in var2 is {1}.", var1, var2);
            
            //use the same variables to switch values
            var1 = var1 + var2;
            var2 = var1 - var2;
            var1 = var1 - var2;

            Console.WriteLine("Value in var1 is {0}, value in var2 is {1}.", var1, var2);

            Console.ReadKey();
        }
    }
}
