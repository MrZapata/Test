﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Example7
    {
        public void fHeader(int value)
        {
            Console.WriteLine(Common.arrHeader[value]);
        }

        public void fAction(string[] args)
        {
            int rows = Convert.ToInt32(args[0]);
            int columns = Convert.ToInt32(args[1]);
            int[,] matrix = new int[rows,columns];
            int[,] tmpMatrix = new int[rows, columns];
            string value = string.Empty;

            //add values to the main matrix
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.WriteLine("Please enter the value for position [{0},{1}]", i, j);
                    value = Console.ReadLine();
                    matrix[i, j] = Convert.ToInt32(value);
                }                
            }

            //copy values from main matrix to temp matrix
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    tmpMatrix[i, j] = matrix[i, j];
                }
            } 
            
            Console.WriteLine("");

            //if value in selected cell is 0 all cells in column and row selected are 0.
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (matrix[i, j] == 0)
                    {
                        for (int k = 0; k < columns; k++)
                        {
                            tmpMatrix[i, k] = 0;
                        }
                    
                        for (int l = 0; l < rows; l++)
                        {
                            tmpMatrix[l, j] = 0;
                        }
                    }
                }
            }

            //show main matrix
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write("{0}", matrix[i, j]);
                }
                Console.WriteLine("");
            }
            
            Console.WriteLine("");

            //show temp matrix
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write("{0}", tmpMatrix[i, j]);
                }
                Console.WriteLine("");
            } 
            
            Console.ReadKey();
        }
    }
}
