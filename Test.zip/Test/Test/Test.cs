﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Test
    {
        Example1 ex1;
        Example2 ex2;
        Example3 ex3;
        Example4 ex4;
        Example5 ex5;
        Example6 ex6;
        Example7 ex7;

        //Constructor
        public Test()
        {
            string option = string.Empty;
            string[] args;

            do
            {
                fShowMenu();
                Console.Out.WriteLine("Please choose an option.");
                option = Console.ReadLine();
                switch (option)
                {
                    case "1":
                        try
                        {
                            Console.Clear();
                            args = new string[2];
                            ex1 = new Example1();
                            ex1.fHeader(Convert.ToInt32(option) - 1);
                            args[0] = "1";
                            args[1] = "10000000";
                            ex1.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    case "2":
                        try
                        {
                            Console.Clear();
                            args = new string[2];
                            ex2 = new Example2();
                            ex2.fHeader(Convert.ToInt32(option) - 1);
                            Console.Out.WriteLine("Please enter the hour");
                            args[0] = Console.ReadLine();
                            Console.Out.WriteLine("Please enter the minutes");
                            args[1] = Console.ReadLine();
                            ex2.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    case "3":
                        try
                        {
                            Console.Clear();
                            args = new string[1];
                            ex3 = new Example3();
                            ex3.fHeader(Convert.ToInt32(option) - 1);
                            Console.Out.WriteLine("Please enter the value between 1 and 3999");
                            args[0] = Console.ReadLine();
                            ex3.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    case "4":
                        try
                        {
                            Console.Clear();
                            ex4 = new Example4();
                            args = new string[2];
                            ex4 = new Example4();
                            ex4.fHeader(Convert.ToInt32(option) - 1);
                            Console.Out.WriteLine("Please enter the first word");
                            args[0] = Console.ReadLine();
                            Console.Out.WriteLine("Please enter the second word");
                            args[1] = Console.ReadLine();
                            ex4.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    case "5":
                        try
                        {
                            Console.Clear();
                            ex5 = new Example5();
                            args = new string[1];
                            ex5 = new Example5();
                            ex5.fHeader(Convert.ToInt32(option) - 1);
                            Console.Out.WriteLine("Please enter a word");
                            args[0] = Console.ReadLine();
                            ex5.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    case "6":
                        try
                        {
                            Console.Clear();
                            args = new string[2];
                            ex6 = new Example6();
                            ex6.fHeader(Convert.ToInt32(option) - 1);
                            Console.Out.WriteLine("Please enter the first value");
                            args[0] = Console.ReadLine();
                            Console.Out.WriteLine("Please enter the second value");
                            args[1] = Console.ReadLine();
                            ex6.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    case "7":
                        try
                        {
                            Console.Clear();
                            args = new string[2];
                            ex7 = new Example7();
                            ex7.fHeader(Convert.ToInt32(option) - 1);
                            Console.Out.WriteLine("Please enter the number of rows.");
                            args[0] = Console.ReadLine();
                            Console.Out.WriteLine("Please enter the number of columns.");
                            args[1] = Console.ReadLine();
                            ex7.fAction(args);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;
                    default:
                        break;
                }
            } while (!option.Equals("0"));
        }

        //Main menu
        public void fShowMenu()
        {
            Console.Clear();
            Console.Out.WriteLine("MENU");
            Console.Out.WriteLine("1: Example 1.");
            Console.Out.WriteLine("2: Example 2.");
            Console.Out.WriteLine("3: Example 3.");
            Console.Out.WriteLine("4: Example 4.");
            Console.Out.WriteLine("5: Example 5.");
            Console.Out.WriteLine("6: Example 6.");
            Console.Out.WriteLine("7: Example 7.");
            Console.Out.WriteLine("");
            Console.Out.WriteLine("0: Salir.");
        }

        static void Main(string[] args)
        {
            new Test();
        }
    }
}
