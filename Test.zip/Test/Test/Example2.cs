﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Example2
    {
        public void fHeader(int value)
        {
            Console.WriteLine(Common.arrHeader[value]);
        }

        public void fAction(string[] args)
        {
            int hour = Convert.ToInt32(args[0]);
            int minutes = Convert.ToInt32(args[1]);
            double angle1;
            double angle2;

            if(hour >= 12)
                hour -= 12;

            //Method 1
            angle1 = (5.5 * minutes) - (30 * hour);

            //Method 2
            angle2 = -(5.5 * minutes) + (30 * hour);

            //validate wich method has positive value
            Console.WriteLine("Method1 = Angle of {0} hours and {1} minutes is {2} grades.", hour, minutes, ((angle1 >= 0) ? angle1 : angle2) );
            Console.ReadKey();
        }
    }
}
