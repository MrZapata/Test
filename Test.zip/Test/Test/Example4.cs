﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Example4
    {
        public void fHeader(int value)
        {
            Console.WriteLine(Common.arrHeader[value]);
        }

        public void fAction(string[] args)
        {
            string word1 = args[0];
            string word2 = args[1];
            string tmpWord1;
            string tmpWord2;
            Char[] arry1;
            Char[] arry2;

            //is not an anagram if length of both strings are different
            if (word1.Length != word2.Length)
            {
                Console.WriteLine("{0} is not an anagram of {1}.", word1, word2);
            }
            else 
            {
                //convert to array chars
                arry1 = word1.ToCharArray();
                arry2 = word2.ToCharArray();

                //sort the array chars
                Array.Sort(arry1);
                Array.Sort(arry2);

                //convert to string the array chars
                tmpWord1 = arry1.ToString();
                tmpWord2 = arry2.ToString();

                //compare both strings
                if(tmpWord1.Equals(tmpWord2))
                    Console.WriteLine("{0} is an anagram of {1}.", word1, word2);
                else
                    Console.WriteLine("{0} is not an anagram of {1}.", word1, word2);
            }
            Console.ReadKey();
        }
    }
}
