﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Example5
    {
        public void fHeader(int value)
        {
            Console.WriteLine(Common.arrHeader[value]);
        }

        public void fAction(string[] args)
        {
            char[] arry = args[0].ToCharArray();
            int repeated = 1; //count repeated values
            string tempStr = string.Empty;

            for (int i = 0; i < (arry.Length - 1); i++)
            {
                //if current char and next char are the same
                if (arry[i].Equals(arry[i + 1]))
                {
                    repeated++;
                    if ((i + 1) == (arry.Length - 1))
                    {
                        tempStr += arry[i];
                        tempStr += repeated;
                        repeated = 1;
                    }
                }
                else
                {
                    tempStr += arry[i];
                    tempStr += repeated;
                    repeated = 1;
                }
            }

            Console.WriteLine("String {0} compressed is {1} .", args[0], ((tempStr.Length < args[0].Length) ? tempStr : args[0]));
            Console.ReadKey();
        }
    }
}
