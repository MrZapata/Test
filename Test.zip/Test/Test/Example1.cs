﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class Example1 : ITest
    {
        public void fHeader(int value)
        {
            Console.WriteLine(Common.arrHeader[value]);
        }

        //function that generates  the operation.
        public void fAction(string[] args)
        {
            double result = 0;

            //moves over all the values, apply the formula and add the result in a variable.
            for (int k = Convert.ToInt32(args[0]); k <= Convert.ToInt32(args[1]); k++ )
            {
                result += (Math.Pow(-1, (k + 1)) / ((2 * k) - 1));
            }

            Console.WriteLine("Result is {0}.", (4 * result));
            Console.ReadKey();
        }
    }
}
